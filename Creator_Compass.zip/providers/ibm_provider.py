import os

from dotenv import load_dotenv
from groq import Groq

load_dotenv()


class GroqProvider:

    def __init__(self):

        api_key = os.getenv("GROQ_API_KEY")

        if not api_key:

            raise ValueError(

                "GROQ_API_KEY not found."

            )

        self.client = Groq(

            api_key=api_key

        )

    # ======================================================
    # NORMAL CHAT
    # ======================================================

    def generate(

        self,

        conversation,

        system_prompt

    ) -> str:

        messages = [

            {

                "role": "system",

                "content": system_prompt

            }

        ]

        for message in conversation:

            messages.append(

                {

                    "role": message["role"],

                    "content": message["content"]

                }

            )

        response = self.client.chat.completions.create(

            model="llama-3.3-70b-versatile",

            messages=messages,

            temperature=0.7,

            max_completion_tokens=600

        )

        return response.choices[0].message.content

    # ======================================================
    # CREATOR DASHBOARD ANALYSIS
    # ======================================================

    def analyze_content(

        self,

        content

    ) -> str:

        dashboard_prompt = """

You are Creator Compass Creator Dashboard.

Analyze the user's content.

Return ONLY valid JSON.

Do not explain anything.

Do not use Markdown.

Return exactly this format:

{

"overall":85,

"title":17,

"hook":16,

"seo":18,

"creativity":17,

"audience":17,

"strengths":[

"Strength 1",

"Strength 2",

"Strength 3"

],

"suggestions":[

"Suggestion 1",

"Suggestion 2",

"Suggestion 3"

]

}

Scores:

overall -> /100

title -> /20

hook -> /20

seo -> /20

creativity -> /20

audience -> /20

Only return JSON.

"""

        response = self.client.chat.completions.create(

            model="llama-3.3-70b-versatile",

            messages=[

                {

                    "role": "system",

                    "content": dashboard_prompt

                },

                {

                    "role": "user",

                    "content": content

                }

            ],

            temperature=0.2,

            max_completion_tokens=500

        )

        return response.choices[0].message.content